﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SovoktvAPI.EPG
{
    public class EpgNext2
    {
        public string chid {get;set;}
        public string progname {get;set;}
        public DateTime start{get;set;}
        public DateTime end { get; set; }
    }
}
