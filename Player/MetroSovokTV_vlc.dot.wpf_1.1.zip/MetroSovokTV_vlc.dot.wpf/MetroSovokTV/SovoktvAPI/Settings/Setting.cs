﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SovoktvAPI.Settings
{
    public class Setting
    {
        public int id_streamer { get; set; }
        public string timezone { get; set; }
        public string buffer { get; set; }
        public string deinterlace { get; set; }
    }
}
