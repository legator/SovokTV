﻿using SovoktvAPI;
using SovoktvAPI.Channels;
using SovoktvAPI.EPG;
using SovoktvAPI.User;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetroSovokTV.Model
{
    public class MainViewModel : ViewModelBase
    {
        private SovokAPI api = new SovokAPI();

        public Account UserAccount
        {
            get
            {
                if (api.Account != null)
                    return api.Account;
                else return null;
            }
            set
            {
                if (api.Account == value)
                    return;
                api.Account = value;
                base.RaisePropertyChanged("UserAccount");
            }
        }

        private Channel active_channel;
        public Channel Active_Channel
        {
            get { return this.active_channel; }
            set
            {
                if (this.active_channel == value)
                {
                    return;
                }
                this.active_channel = value;
                base.RaisePropertyChanged("Active_Channel");
            }
        }

        private int selchi = -1;
        public int SelectedChannelIndex
        {
            get { return this.selchi; }
            set
            {
                if (this.selchi == value) return;
                this.selchi = value;
                base.RaisePropertyChanged("SelectedChannelIndex");
            }
        }

        private Uri stream_url;
        public Uri StreamURL
        {
            get { return this.stream_url; }
            set
            {
                if (this.stream_url == value) return;
                this.stream_url = value;
                base.RaisePropertyChanged("StreamURL");
            }
        }

        private Double volume = 50;
        public Double Volume
        {
            get { return this.volume; }
            set
            {
                if (this.volume == value) return;
                this.volume = value;
                base.RaisePropertyChanged("Volume");
            }
        }

        private List<Programs> epg;
        public List<Programs> EPG
        {
            get { return this.epg; }
            set
            {
                if (this.epg == value) return;
                this.epg = value;
            }
        }
        #region epg

        private string timestart = "NaN";
        public string EpgTimeStart
        {
            get { return this.timestart; }
            set
            {
                if (this.timestart == value) return;
                this.timestart = value;
                base.RaisePropertyChanged("EpgTimeStart");
            }
        }

        private string timeend = "NaN";
        public string EpgTimeEnd
        {
            get { return this.timeend; }
            set
            {
                if (this.timeend == value) return;
                this.timeend = value;
                base.RaisePropertyChanged("EpgTimeEnd");
            }
        }

        private double epgprogress;
        public double EpgProgress
        {
            get { return this.epgprogress; }
            set
            {
                if (this.epgprogress == value) return;
                this.epgprogress = value;
                base.RaisePropertyChanged("EpgProgress");
            }
        }
        #endregion

        public double Time
        {
            get { return api.Time; }
        }

        #region is
        private bool islogin = false;
        public bool IsLogin
        {
            get
            {
                return this.islogin;
            }
            set
            {
                bool flag = this.islogin != value;
                if (flag)
                {
                    this.islogin = value;
                    base.RaisePropertyChanged("IsLogin");
                }
            }
        }

        private bool isplay = false;
        public bool IsPlay
        {
            get
            {
                return this.isplay;
            }
            set
            {
                bool flag = this.isplay != value;
                if (flag)
                {
                    this.isplay = value;
                    base.RaisePropertyChanged("IsPlay");
                }
            }
        }

        private bool ischannellist = false;
        public bool IsChannelList
        {
            get
            {
                return this.ischannellist;
            }
            set
            {
                bool flag = this.ischannellist != value;
                if (flag)
                {
                    this.ischannellist = value;
                    base.RaisePropertyChanged("IsChannelList");
                }
            }
        }

        private bool isepg = false;
        public bool IsEpg
        {
            get
            {
                return this.isepg;
            }
            set
            {
                bool flag = this.isepg != value;
                if (flag)
                {
                    this.isepg = value;
                    base.RaisePropertyChanged("IsEpg");
                }
            }
        }

        private bool isset = false;
        public bool IsSet
        {
            get
            {
                return this.isset;
            }
            set
            {
                bool flag = this.isset != value;
                if (flag)
                {
                    this.isset = value;
                    base.RaisePropertyChanged("IsSet");
                }
            }
        }

        private bool ismute = false;
        public bool IsMute
        {
            get
            {
                return this.ismute;
            }
            set
            {
                bool flag = this.ismute != value;
                if (flag)
                {
                    this.ismute = value;
                    base.RaisePropertyChanged("IsMute");
                }
            }
        }

        private bool isfavorite = false;
        public bool IsFavorite
        {
            get
            {
                return this.isfavorite;
            }
            set
            {
                bool flag = this.isfavorite != value;
                if (flag)
                {
                    this.isfavorite = value;
                    base.RaisePropertyChanged("IsFavorite");
                }
            }
        }

        private bool ispanel = false;
        public bool IsPanel
        {
            get { return this.ispanel; }
            set
            {
                if (this.ispanel == value) return;
                this.ispanel = value;
                base.RaisePropertyChanged("IsPanel");
            }
        }
        #endregion

        public async Task Login(string login, string pass, string code)
        {
            try
            {
                Account acc = await api.Auth(login, pass, code);
                api.Account = acc;
                islogin = true;
            }
            catch (Exception ex)
            {
                islogin = false;
                throw new System.Exception("Login processing error");
            }

        }

        public async Task GetChannels()
        {
            try
            {
                Task c = api.GetChannelList();
                await c;
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public async Task GetSettings()
        {
            try
            {
                Task c = api.GetChannelList();
                await c;
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public async Task GetFavoriteChannel()
        {
            try
            {
                Task c = api.GetFavorites();
                await c;
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public async Task GetStreamers()
        {
            try
            {
                await api.GetStreamers();
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public async Task SetStreamServer(int streamer)
        {
            await api.SetSetting(streamer);
        }

        public async Task SetTimeZone(string date)
        {
            Task c = api.SetSetting(date);
            await c;
            //return c;
        }

        public void Logoff()
        {
            api.Account = null;
            islogin = false;
        }

        public async Task GetAccount()
        {
            try
            {
                await api.GetAccount();
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public void ChangeChannel()
        {
            OpenStream(Active_Channel.id);
            IsFavoriteChannel();
        }

        private string TimeFromate(string dt)
        {
            if (dt.Length == 1)
            {
                dt = "0" + dt;
            }
            return dt;
        }

        public string OpenChannel(string id)
        {
            string url = "";
            try
            {
                string u = api.GetUrl(id);
                url = u.Split(' ')[0];
                //stream_url = new Uri(url);
                IsFavoriteChannel();
                //open_epg();
                
                isplay = false;
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
            return url;
        }

        private void OpenStream(string id)
        {
            string url = App.ViewModel.OpenChannel(id);
            try
            {
                Uri u = new Uri(url.Replace("http/ts://", "http://").Trim());
                if (u != App.ViewModel.StreamURL)
                {
                    App.ViewModel.StreamURL = u;
                }
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public async Task GetEpg()
        {
            DateTime dt = new DateTime();
            dt = DateTime.Now;
            string[] dts = new string[3];
            dts[2] = dt.Year.ToString()[2] + "" + dt.Year.ToString()[3];
            if (dt.Month.ToString().Length == 1)
            {
                dts[1] = "0" + dt.Month.ToString();
            }
            else dts[1] = dt.Month.ToString();
            if (dt.Day.ToString().Length == 1)
            {
                dts[0] = "0" + dt.Day.ToString();
            }
            else dts[0] = dt.Day.ToString();
            Task<List<Programs>> c = api.Epg(active_channel.id, dts[0] + dts[1] + dts[2]);
            epg = await c;
        }

        public EpgNext2 GetEpg2(string id)
        {
            api.Epg2(id);
            return api.EPG2;
        }

        public async Task AddDelFavoriteChannel()
        {
            api.SetFavoriteChannel(active_channel.id);
            await GetChannels();
            await GetFavoriteChannel();
        }

        public void IsFavoriteChannel()
        {
            IsFavorite = false;
            foreach (FavoriteChannel item in UserAccount.favorite_channel)
            {
                if (active_channel.id == item.id_channel)
                {
                    IsFavorite = true;
                    break;
                }
            }
        }
    }
}
