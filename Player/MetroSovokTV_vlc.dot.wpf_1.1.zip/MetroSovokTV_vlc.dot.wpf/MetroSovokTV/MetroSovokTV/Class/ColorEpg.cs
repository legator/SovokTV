﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace MetroSovokTV.Class
{
    public class ColorEpg
    {
        public Brush Color { get; set; }
        public string progname { get; set; }
        public string ut_start { get; set; }
        public string t_start { get; set; }
    }
}
