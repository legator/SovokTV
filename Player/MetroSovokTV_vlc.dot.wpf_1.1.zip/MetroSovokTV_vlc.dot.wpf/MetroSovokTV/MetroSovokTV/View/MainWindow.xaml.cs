﻿using MetroSovokTV.Class;
using SovoktvAPI.Channels;
using SovoktvAPI.EPG;
using SovoktvAPI.User;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Vlc.DotNet.Core;
using Vlc.DotNet.Core.Medias;

namespace MetroSovokTV.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IntPtr handle;
        public bool iscontrol = true;
        public bool isfullscreen = false;
        public double left { get; set; }
        public double top { get; set; }
        public bool istopmost = false;
        private double VolumeValue { get; set; }
        private int ind = -1;
        private int index = -1;
        private int chc = -1;
        private ObservableCollection<GroupChannel> _groups;
        private ObservableCollection<Programs> _epg_groups;
        private GridLengthConverter gridLengthConverter = new GridLengthConverter();
        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();

        public MainWindow()
        {
            #region video player setup
            // Set libvlc.dll and libvlccore.dll directory path
            VlcContext.LibVlcDllsPath = MetroSovokTV.Properties.Settings.Default.VlcPath;

            // Set the vlc plugins directory path
            VlcContext.LibVlcPluginsPath = MetroSovokTV.Properties.Settings.Default.VlcPath + @"\plugins";

            // Ignore the VLC configuration file
            VlcContext.StartupOptions.IgnoreConfig = true;

            VlcContext.StartupOptions.ShowLoggerConsole = false;
            VlcContext.StartupOptions.ScreenSaverEnabled = false;

            // Enable file based logging
            VlcContext.StartupOptions.LogOptions.LogInFile = true;

            // Shows the VLC log console (in addition to the applications window)
            VlcContext.StartupOptions.LogOptions.ShowLoggerConsole = false;

            // Set the log level for the VLC instance
            VlcContext.StartupOptions.LogOptions.Verbosity = VlcLogVerbosities.None;

            // Disable showing the movie file name as an overlay
            VlcContext.StartupOptions.AddOption("--no-video-title-show");

            // Pauses the playback of a movie on the last frame
            //VlcContext.StartupOptions.AddOption("--play-and-pause");

            // Initialize the VlcContext
            if (!VlcContext.IsInitialized)
            {
                VlcContext.Initialize();
            }
            #endregion

            InitializeComponent();
            this.DataContext = App.ViewModel;

            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 1, 0);
            dispatcherTimer.Start();
        }

        #region move event
        private void WindowMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && e.GetPosition(this).Y < 38)
            {
                DragMove();
            }
        }

        private void WindowSourceInit(object sender, EventArgs e)
        {
            handle = new WindowInteropHelper(this).Handle;
        }

        private void ResizeGridMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                SizeWindow(handle);
            }
        }

        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr hWnd, UInt32 msg, UInt32 wParm, IntPtr IParam);

        public static void SizeWindow(IntPtr handle)
        {
            SendMessage(handle, 274, 61448, IntPtr.Zero);
        }

        private void OpenControl(object sender, MouseButtonEventArgs e)
        {
            if (e.RightButton == MouseButtonState.Pressed)
            {
                iscontrol = !iscontrol;
            }

            if (iscontrol)
            {
                TopHeight.Height = (GridLength)gridLengthConverter.ConvertFrom("30");
                BottomHeight.Height = (GridLength)gridLengthConverter.ConvertFrom("90");
                if (App.ViewModel.IsChannelList)
                {
                    LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("300");
                }
                if (App.ViewModel.IsEpg)
                {
                    LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("300");
                }
            }
            else
            {
                TopHeight.Height = (GridLength)gridLengthConverter.ConvertFrom("0");
                BottomHeight.Height = (GridLength)gridLengthConverter.ConvertFrom("0");
                LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("0");
                App.ViewModel.IsChannelList = App.ViewModel.IsEpg = false;
            }
        }
        #endregion

        #region top controls event
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ChangeMode_Click(object sender, RoutedEventArgs e)
        {
            isfullscreen = !isfullscreen;
            if (isfullscreen)
            {
                this.Width = System.Windows.SystemParameters.PrimaryScreenWidth;
                this.Height = System.Windows.SystemParameters.PrimaryScreenHeight;
                left = this.Left;
                top = this.Top;
                this.Left = 0;
                this.Top = 0;
                Topmost = true;
            }
            else
            {
                this.Width = 525;
                this.Height = 350;

                this.Left = left;
                this.Top = top;
                Topmost = istopmost;
            }
        }

        private void Pin_Click(object sender, RoutedEventArgs e)
        {
            istopmost = !istopmost;
            this.Topmost = istopmost;
        }

        private void Min_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            App.ViewModel.IsSet = !App.ViewModel.IsSet;
            App.ViewModel.IsEpg = false;
            App.ViewModel.IsChannelList = false;
            if (App.ViewModel.IsSet)
            {
                App.ViewModel.IsPanel = true;
                LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("300");
                LoadData();
            }
            else
            {
                App.ViewModel.IsPanel = false;
                LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("0");
            }
        }
        #endregion

        #region bottom event
        private void EPG_Click(object sender, RoutedEventArgs e)
        {
            App.ViewModel.IsChannelList = false;
            App.ViewModel.IsSet = false;
            if (App.ViewModel.IsEpg)
            {
                App.ViewModel.IsPanel = true;
                LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("300");
                LoadEPG();
            }
            else
            {
                App.ViewModel.IsPanel = false;
                LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("0");
            }
        }

        private void Channel_Click(object sender, RoutedEventArgs e)
        {
            App.ViewModel.IsEpg = false;
            App.ViewModel.IsSet = false;
            if (App.ViewModel.IsChannelList)
            {
                App.ViewModel.IsPanel = true;
                LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("300");
                Grouped();
            }
            else
            {
                App.ViewModel.IsPanel = false;
                LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("0");
            }
        }

        private void PlayStop_Click(object sender, RoutedEventArgs e)
        {
            if (App.ViewModel.IsPlay)
            {
                //stop
                myVlcControl.Stop();
            }
            else
            {
                //stop
                Play();
            }
        }

        public async Task Play()
        {
            App.ViewModel.IsPlay = true;
            myVlcControl.Media = new LocationMedia(App.ViewModel.StreamURL.ToString());
            myVlcControl.AudioProperties.Volume = Convert.ToInt32(VolumeSlider.Value);
            myVlcControl.Play();
            myVlcControl.VideoProperties.Scale = 2.0f;
        }

        private void Like_Click(object sender, RoutedEventArgs e)
        {
            App.ViewModel.AddDelFavoriteChannel();
            Grouped();
        }

        private void VolumeMuteClick(object sender, RoutedEventArgs e)
        {
            if (App.ViewModel.IsMute)
            {
                VolumeValue = App.ViewModel.Volume;
                App.ViewModel.Volume = 0;
                myVlcControl.AudioProperties.Volume = 0;
            }
            else
            {
                App.ViewModel.Volume = VolumeValue;
                myVlcControl.AudioProperties.Volume = Convert.ToInt32(VolumeValue);
                VolumeSlider.Value = VolumeValue;
            }
        }

        private void ChangeVolume(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            App.ViewModel.Volume = VolumeSlider.Value;
            myVlcControl.AudioProperties.Volume = Convert.ToInt32(VolumeSlider.Value);
        }
        #endregion

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            App.ViewModel.IsPanel = false;
            App.ViewModel.IsEpg = false;
            App.ViewModel.IsChannelList = false;
            LeftWidth.Width = (GridLength)gridLengthConverter.ConvertFrom("0");
        }

        #region settings event
        private void LoadData()
        {
            Stream.Items.Clear();
            foreach (StreamServer item in App.ViewModel.UserAccount.streamers)
            {
                ComboBoxItem boxitem = new ComboBoxItem();
                boxitem.Content = item.id;
                boxitem.Name = item.name.Split(' ')[0];
                Stream.Items.Add(boxitem);
            }
            DeinterlaceValue.Text = App.ViewModel.UserAccount.settings.deinterlace;
            BufferValue.Text = App.ViewModel.UserAccount.settings.buffer;
            int i = -1; bool isbreak = false;
            foreach (ComboBoxItem item in TimeZone.Items)
            {
                i++;
                if (item.Content.ToString() == App.ViewModel.UserAccount.settings.timezone)
                {
                    isbreak = true;
                    break;
                }
            }
            if (isbreak) TimeZone.SelectedIndex = i;
            else TimeZone.SelectedIndex = -1;
            i = -1; isbreak = false;
            foreach (ComboBoxItem item in Stream.Items)
            {
                i++;
                if (item.Content.ToString() == App.ViewModel.UserAccount.settings.id_streamer.ToString())
                {
                    isbreak = true;
                    break;
                }
            }
            if (isbreak) Stream.SelectedIndex = i;
            else Stream.SelectedIndex = -1;
            Stream.SelectedIndex = i;
        }

        private void Logoff_Click(object sender, RoutedEventArgs e)
        {
            MetroSovokTV.Properties.Settings.Default.Password = "";
            MetroSovokTV.Properties.Settings.Default.UserName = "";
            MetroSovokTV.Properties.Settings.Default.Code = "";
            MetroSovokTV.Properties.Settings.Default.Save();
            App.ViewModel.Logoff();
            LoginView loginview = new LoginView();
            loginview.Show();
            this.Close();
        }

        private void ChangedTimeZone(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem item = (ComboBoxItem)TimeZone.SelectedItem;
            if (item.Content.ToString() == App.ViewModel.UserAccount.settings.timezone)
            {
                return;
            }
            App.ViewModel.SetTimeZone(item.Content.ToString());
            App.ViewModel.UserAccount.settings.timezone = item.Content.ToString();
            Update();
        }

        private void ChangeStream(object sender, SelectionChangedEventArgs e)
        {
            if (Stream.SelectedIndex == -1)
            {
                return;
            }
            StreamServer st = App.ViewModel.UserAccount.streamers[Stream.SelectedIndex];
            if (st.id == App.ViewModel.UserAccount.settings.id_streamer.ToString())
            {
                return;
            }
            App.ViewModel.SetStreamServer(Convert.ToInt32(st.id));
            App.ViewModel.UserAccount.settings.id_streamer = Convert.ToInt32(st.id);
        }
        #endregion

        #region channel list event
        private void Grouped()
        {
            _groups = new ObservableCollection<GroupChannel>();
            ChCategory.Items.Clear();
            foreach (Group item in App.ViewModel.UserAccount.channel_group)
            {
                ComboBoxItem cbi = new ComboBoxItem();
                cbi.Name = item.name;
                cbi.Content = item.name;
                ChCategory.Items.Add(cbi);
                ind++;

                foreach (Channel it in item.ChannelsList)
                {
                    GroupChannel g = new GroupChannel();
                    g.Group = item.name;
                    g.epg_end = it.epg_end;
                    g.epg_progname = it.epg_progname;
                    g.epg_start = it.epg_start;
                    g.icon = "http://sovok.tv" + it.icon;
                    g.id = it.id;
                    g.is_protected = it.is_protected;
                    g.is_video = it.is_video;
                    g.name = it.name;
                    _groups.Add(g);
                }
            }
            ComboBoxItem fcbi = new ComboBoxItem();
            fcbi.Content = fcbi.Name = "Favorite";
            ChCategory.Items.Add(fcbi);
            ind++;
            list.ItemsSource = _groups;
        }

        private async void ChangeActiveChannel(object sender, SelectionChangedEventArgs e)
        {
            Channel c = new Channel();
            index = list.SelectedIndex;
            if (index <= -1)
            {
                return;
            }
            var g = (GroupChannel)list.SelectedItems[0];

            c.epg_end = g.epg_end;
            c.epg_progname = g.epg_progname;
            c.epg_start = g.epg_start;
            c.icon = g.icon;
            c.id = g.id;
            c.is_protected = g.is_protected;
            c.is_video = g.is_video;
            c.name = g.name;
            App.ViewModel.Active_Channel = c;
            App.ViewModel.EpgTimeStart = TimeFromate(c.epg_start.AddHours(App.ViewModel.Time).Hour.ToString()) + ":" + TimeFromate(c.epg_start.AddHours(App.ViewModel.Time).Minute.ToString()) + ":00";
            App.ViewModel.EpgTimeEnd = TimeFromate(c.epg_end.AddHours(App.ViewModel.Time).Hour.ToString()) + ":" + TimeFromate(c.epg_end.AddHours(App.ViewModel.Time).Minute.ToString()) + ":00";

            var dif = (c.epg_end.AddHours(App.ViewModel.Time) - c.epg_start.AddHours(App.ViewModel.Time)).TotalMinutes;
            var dif1 = (DateTime.Now - c.epg_start.AddHours(App.ViewModel.Time)).TotalMinutes;
            App.ViewModel.EpgProgress = Math.Round(dif1 / dif * 100);
            App.ViewModel.ChangeChannel();
            Play();
        }

        private string TimeFromate(string dt)
        {
            if (dt.Length == 1)
            {
                dt = "0" + dt;
            }
            return dt;
        }

        private void ChangeChannelCategory(object sender, SelectionChangedEventArgs e)
        {
            chc = ChCategory.SelectedIndex;
            ShowCategory(ChCategory.SelectedIndex);
        }

        private void ShowCategory(int index)
        {
            _groups.Clear(); bool isb = false;
            if (index == ind)
            {
                foreach (FavoriteChannel item in App.ViewModel.UserAccount.favorite_channel)
                {
                    var fg = new GroupChannel();
                    fg.Group = "Favorite";
                    foreach (Group it in App.ViewModel.UserAccount.channel_group)
                    {
                        foreach (Channel itm in it.ChannelsList)
                        {
                            if (itm.id == item.id_channel)
                            {
                                fg.epg_end = itm.epg_end;
                                fg.epg_progname = itm.epg_progname;
                                fg.epg_start = itm.epg_start;
                                fg.icon = itm.icon.ToString();
                                fg.name = itm.name;
                                fg.icon = "http://sovok.tv" + itm.icon;
                                isb = true;
                                break;
                            }
                            if (isb)
                            {
                                break;
                            }
                        }
                    }
                    _groups.Add(fg);
                }
            }
            else
            {
                if (index <= 0 || index >= App.ViewModel.UserAccount.channel_group.Count)
                {
                    index = 0;
                }
                try
                {
                    Group item = App.ViewModel.UserAccount.channel_group[index];

                    foreach (Channel it in item.ChannelsList)
                    {
                        var g = new GroupChannel();
                        g.Group = item.name;
                        g.epg_end = it.epg_end;
                        g.epg_progname = it.epg_progname;
                        g.epg_start = it.epg_start;
                        g.icon = "http://sovok.tv" + it.icon;
                        g.id = it.id;
                        g.is_protected = it.is_protected;
                        g.is_video = it.is_video;
                        g.name = it.name;
                        _groups.Add(g);
                    }
                    //
                }
                catch (Exception)
                {
                    MessageBox.Show(index + "\n" + App.ViewModel.UserAccount.channel_group.Count);
                }
            }
            list.ItemsSource = _groups;
        }
        #endregion

        #region epg view
        private async Task LoadEPG()
        {
            List<Programs> lp = new List<Programs>();
            await App.ViewModel.GetEpg();
            lp = App.ViewModel.EPG;

            List<ColorEpg> lpc = new List<ColorEpg>();
            await App.ViewModel.GetEpg();
            bool isf = false;
            Brush w = new SolidColorBrush(Colors.White);
            Brush b = new SolidColorBrush(Colors.Gray);
            foreach (Programs item in App.ViewModel.EPG)
            {
                ColorEpg c = new ColorEpg();
                c.progname = item.progname;
                c.t_start = item.t_start;
                if (App.ViewModel.Active_Channel.epg_progname == c.progname)
                {
                    if (App.ViewModel.Active_Channel.epg_start.AddHours(4).ToShortTimeString() == c.t_start)
                    {
                        c.Color = w;
                        isf = true;
                    }
                    else
                    {
                        if (isf)
                        {
                            c.Color = w;
                        }
                        else c.Color = b;
                    }
                }
                else
                {
                    if (isf)
                    {
                        c.Color = w;
                    }
                    else c.Color = b;
                }
                lpc.Add(c);

            }
            ChannelEpgView.ItemsSource = lpc;
        }

        public DateTime ConvertFromUnixTimestamp(double timestamp)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return origin.AddSeconds(timestamp);
        }
        #endregion

        #region update channel info
        void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            Update();
        }

        private void Update()
        {
            MessageBox.Show("update");
            //update progress
            App.ViewModel.EpgTimeStart = TimeFromate(App.ViewModel.Active_Channel.epg_start.AddHours(App.ViewModel.Time).Hour.ToString()) + ":" + TimeFromate(App.ViewModel.Active_Channel.epg_start.AddHours(App.ViewModel.Time).Minute.ToString()) + ":00";
            App.ViewModel.EpgTimeEnd = TimeFromate(App.ViewModel.Active_Channel.epg_end.AddHours(App.ViewModel.Time).Hour.ToString()) + ":" + TimeFromate(App.ViewModel.Active_Channel.epg_end.AddHours(App.ViewModel.Time).Minute.ToString()) + ":00";

            var dif = (App.ViewModel.Active_Channel.epg_end.AddHours(App.ViewModel.Time) - App.ViewModel.Active_Channel.epg_start.AddHours(App.ViewModel.Time)).TotalMinutes;
            var dif1 = (DateTime.Now - App.ViewModel.Active_Channel.epg_start.AddHours(App.ViewModel.Time)).TotalMinutes;
            App.ViewModel.EpgProgress = Math.Round(dif1 / dif * 100);
            //end

            _groups = new ObservableCollection<GroupChannel>();
            foreach (Group item in App.ViewModel.UserAccount.channel_group)
            {
                foreach (Channel it in item.ChannelsList)
                {
                    GroupChannel g = new GroupChannel();

                    int result = DateTime.Compare(DateTime.Now, it.epg_end);
                    if (result < 0)
                    {
                        EpgNext2 e2 = App.ViewModel.GetEpg2(it.id);
                        it.epg_end = e2.end;
                        it.epg_start = e2.start;
                        it.epg_progname = e2.progname;
                    }
                    g.epg_end = it.epg_end;
                    g.epg_progname = it.epg_progname;
                    g.epg_start = it.epg_start;
                    g.Group = item.name;
                    g.icon = "http://sovok.tv" + it.icon;
                    g.id = it.id;
                    g.is_protected = it.is_protected;
                    g.is_video = it.is_video;
                    g.name = it.name;
                    _groups.Add(g);
                }
            }
            list.ItemsSource = _groups;
        }
        #endregion
    }
}

