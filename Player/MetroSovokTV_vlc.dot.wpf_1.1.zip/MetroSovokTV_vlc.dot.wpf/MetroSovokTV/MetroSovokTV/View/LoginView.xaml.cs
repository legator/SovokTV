﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MetroSovokTV.View
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : Window
    {
        private string UserName { get; set; }
        private string Password { get; set; }
        private string Code { get; set; }
        private string vlcpath { get; set; }
        private MainWindow main = new MainWindow();

        public LoginView()
        {
            LoadUserCredential();
            if (App.ViewModel.IsLogin)
            {
                main.Show();
                this.Close();
            }
            else
            {
                InitializeComponent();
                login.Text = UserName;
                pass.Password = Password;
                code.Text = Code;
                vlc_path.Text = vlcpath;
            }
        }

        private void LoadUserCredential()
        {
            try
            {
                UserName = MetroSovokTV.Properties.Settings.Default.UserName;
                Password = MetroSovokTV.Properties.Settings.Default.Password;
                Code = MetroSovokTV.Properties.Settings.Default.Code;
                vlcpath = MetroSovokTV.Properties.Settings.Default.VlcPath;
                string path = vlcpath + @"\vlc.exe";
                if (!File.Exists(path))
                {
                    MessageBox.Show("Error in vlc directory path");
                    return;
                }
                if (!String.IsNullOrEmpty(UserName) || !String.IsNullOrEmpty(Password))
                {
                    Login();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to load user login data\n"+ex.StackTrace);
            }
        }

        private async Task Login()
        {
            try
            {
                App.ViewModel.Login(UserName, Password, Code);
                this.Close();
                main.Show();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void WindowMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && e.GetPosition(this).Y < 38)
            {
                DragMove();
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            login.Text = "";
            pass.Password = "";
            code.Text = "";
            vlc_path.Text = "";
        }

        private void Min_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.Shutdown();
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            string path = vlc_path.Text + @"\vlc.exe";
            if (!File.Exists(path))
            {
                MessageBox.Show("Error in vlc directory path");
                return;
            }
            if (String.IsNullOrEmpty(login.Text) || String.IsNullOrEmpty(pass.Password))
            {
                MessageBox.Show("Fill username and passwork fild");
                return;
            }
            try
            {
                LoginButton.Visibility = Visibility.Hidden;
                await App.ViewModel.Login(login.Text, pass.Password, code.Text);
                MetroSovokTV.Properties.Settings.Default.Code = code.Text;
                MetroSovokTV.Properties.Settings.Default.UserName = login.Text;
                MetroSovokTV.Properties.Settings.Default.Password = pass.Password;
                MetroSovokTV.Properties.Settings.Default.VlcPath = vlc_path.Text;
                MetroSovokTV.Properties.Settings.Default.Save();
                this.Close();
                main.Show();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); LoginButton.Visibility = Visibility.Visible; }
        }
    }
}
