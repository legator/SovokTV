﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SovoktvAPI.User
{
    public class Service
    {
        public string id { get; set; }
        public string type { get; set; }
        public string name { get; set; }
        public string expire { get; set; }
    }
}
