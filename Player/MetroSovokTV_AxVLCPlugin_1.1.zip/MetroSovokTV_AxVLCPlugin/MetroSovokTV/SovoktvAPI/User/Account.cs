﻿using SovoktvAPI.Channels;
using SovoktvAPI.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SovoktvAPI.User
{
    public class Account
    {
        public string sid { get; set; }
        public string sid_name { get; set; }
        public string login { get; set; }
        public string balance { get; set; }
        public List<Service> services { get; set; }
        public string protect_code { get; set; }
        public Setting settings { get; set; }
        public List<Group> channel_group { get; set; }
        public List<FavoriteChannel> favorite_channel { get; set; }
        public List<StreamServer> streamers { get; set; }
    }
}
