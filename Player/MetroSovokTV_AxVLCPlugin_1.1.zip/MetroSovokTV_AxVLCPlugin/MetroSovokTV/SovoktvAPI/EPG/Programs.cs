﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SovoktvAPI.EPG
{
    public class Programs
    {
        public string progname { get; set; }
        public string ut_start { get; set; }
        public string t_start { get; set; }
    }
}
