﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SovoktvAPI.EPG
{
    public class EpgNext
    {
        public string id { get; set; }
        public string ts { get; set; }
        public string progname { get; set; }
    }
}
