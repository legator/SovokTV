﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetroSovokTV.Class
{
    public class GroupChannel:SovoktvAPI.Channels.Channel
    {
        public string Group { get; set; }
    }
}
